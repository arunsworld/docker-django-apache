from __future__ import absolute_import
from hamcrest.core import *
from hamcrest.library import *

__version__ = "2.0.0a1"
__author__ = "Chris Rose"
__copyright__ = "Copyright 2014 hamcrest.org"
__license__ = "BSD, see License.txt"
