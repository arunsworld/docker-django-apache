Dictionary Matchers
-------------------

Matchers of dictionaries.


has_entries
^^^^^^^^^^^

.. automodule:: hamcrest.library.collection.isdict_containingentries
    :exclude-members: has_entries
.. autofunction:: has_entries(matcher_dict)

has_entry
^^^^^^^^^

.. automodule:: hamcrest.library.collection.isdict_containing

has_key
^^^^^^^

.. automodule:: hamcrest.library.collection.isdict_containingkey

has_value
^^^^^^^^^

.. automodule:: hamcrest.library.collection.isdict_containingvalue
